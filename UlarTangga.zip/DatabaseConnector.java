import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/ulartangga?useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    private static final String USERNAME = "project26";
    private static final String PASSWORD = "123";
    
    public static Connection getConnection() throws SQLException {
        try {
            Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            System.out.println("Koneksi ke database berhasil!");
            return connection;
        } catch (SQLException e) {
            System.err.println("Koneksi ke database gagal: " + e.getMessage());
            throw e;
        }
    }

    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            System.out.println("Tes koneksi berhasil!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}