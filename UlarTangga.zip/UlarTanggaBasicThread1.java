public class UlarTanggaBasicThread1 extends Thread {
   public void run() {
      do {
         UlarTangga.dc1 = (int)(Math.random() * 6.0D);
         UlarTangga.dice1.setIcon(UlarTangga.dadu[UlarTangga.dc1]);
         UlarTangga.dc2 = (int)(Math.random() * 6.0D);
         UlarTangga.dice2.setIcon(UlarTangga.dadu[UlarTangga.dc2]);
      } while(!UlarTangga.temp);

   }
}